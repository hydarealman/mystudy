#include<stdio.h>
#include<malloc.h> 
#define MaxSize 100 
typedef int ElementType;
typedef struct SNode *Stack;
struct SNode{
    ElementType Data[MaxSize];
    int Top;
};
Stack S;

Stack CreateStack();  // 初始化堆栈 
int IsFull(Stack S); // 判断堆栈是否已满 
int IsEmpty(Stack S);   // 判断堆栈是否为空 
void Push(Stack S,ElementType item);   // 入栈 
ElementType Pop(Stack S);   // 出栈 

//初始化堆栈
Stack CreateStack() {
    S = (Stack)malloc(sizeof(struct SNode));
    S->Top = -1;
    return S;
}

//是否已满
int IsFull(Stack S) {
    return (S->Top == MaxSize-1);
}

//是否为空
int IsEmpty(Stack S) {
    return (S->Top == -1);
}

//入栈
void Push(Stack S,ElementType item) {
    if (IsFull(S)) {
        printf("堆栈满");
        return;
    }
    else {
        S->Top++;
        S->Data[S->Top] = item;
        return;
    }
}

//出栈
ElementType Pop(Stack S) {
    if (IsEmpty(S)) {
        printf("堆栈已空");
        return 0;
    }
    else {
        ElementType val = S->Data[S->Top];
        S->Top--;
        return val;
    }
}

int main(){
	S = CreateStack();
	printf("5入栈\n");
	Push(S,5);
	printf("7入栈\n");
	Push(S,7);
	printf("66入栈\n");
	Push(S,66);
	printf("%d出栈\n",Pop(S));
	printf("%d出栈\n",Pop(S));
	return 0;
}